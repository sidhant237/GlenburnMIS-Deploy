from flask import Flask, render_template, request, jsonify
from flask_cors import cross_origin
from App import app, mysql
import json, datetime
from dateutil.relativedelta import relativedelta



##################################
#12 FACTORY
@app.route('/factory', methods=['GET', 'POST'])
@cross_origin()
def displayfactory():      
      d1 = request.args.get("start") 
      if not d1:
            d1 = "2020-08-18"
      d11 = "'" + str((datetime.datetime.strptime(d1, '%Y-%m-%d') - relativedelta(years=1))).split(' ')[0] + "'"
      d01 = "'" + str((datetime.datetime.strptime(d1, '%Y-%m-%d') - relativedelta(days=1))).split(' ')[0] + "'"
      d1 = "'" + d1 + "'"
      d0 = "'2020-01-01'"  # start date current year
      d00 = "'2019-01-01'"  # start date last year
      cur = mysql.connection.cursor()
           
      rv = []
      ##TEA MADE
      # [TM TODAY]
      val = "TMEntry.TM_Val "
      tab = "TMEntry"
      cur.execute(f'''select {val} from {tab} where TM_Date = {d1} ''')
      rv.append(cur.fetchall()[0][0])

      # [TM TODATE]
      val1 = "sum(TMEntry.TM_Val)"
      tab1 = "TMEntry"
      cur.execute(f'''select {val1} from {tab1} where TM_Date >= {d0} AND TM_Date <= {d1} ''')
      rv.append(cur.fetchall()[0][0])

      # [TM TODATE LAST YEAR]
      val2 = "sum(TMEntry.TM_Val)"
      tab2 = "TMEntry"
      cur.execute(f'''select {val2} from {tab2} where TM_Date >= {d00} AND TM_Date <= {d11} ''')
      rv.append(cur.fetchall()[0][0])

      #[GL YEST]
      val3 = "sum(FieldEntry.GL_Val)"
      tab3 = "FieldEntry"
      cur.execute(f'''select {val3} from {tab3} where Date = {d01}''')
      rv3 = cur.fetchall()
      y = [i[0] for i in rv3]

      #[TM TODAY]
      val = "TMEntry.TM_Val "
      tab = "TMEntry"
      cur.execute(f'''select {val} from {tab} where TM_Date = {d1} ''')
      rv1 = cur.fetchall()
      x = [i[0] for i in rv1]

      #[GL TODATE]
      val3 = "sum(FieldEntry.GL_Val)"
      tab3 = "FieldEntry"
      cur.execute(f'''select {val3} from {tab3} where Date >= {d0} and Date <= {d01}''')
      rv4 = cur.fetchall()
      yy = [i[0] for i in rv4]
      
      #[TM TODATE]
      val1 = "sum(TMEntry.TM_Val)"
      tab1 = "TMEntry"
      cur.execute(f'''select {val1} from {tab1} where TM_Date >= {d0} AND TM_Date <= {d1} ''')
      rv2 = cur.fetchall()
      xx = [i[0] for i in rv2]

      #[Recovery today]
      z = round((x[0] / y[0])*100,2)
      rv.append(z)

      zz = round((xx[0]/yy[0])*100,2)
      rv.append(zz)   

      column_headers =  ['TMToday', 'TMTodate', 'TMTodateLY', 'RecoveryToday', 'RecoveryTodate']
      
      json_data = []
      json_data.append(dict(zip(column_headers, rv)))
      



#9## GREENLEAF FACTORY

      cur = mysql.connection.cursor()
      
      #DIV NAME
      vala = "DivTab.DIV_NAME"
      taba = "DivTab, SecTab, FieldEntry"
      joia = "(FieldEntry.Sec_ID=SecTab.Sec_ID) AND (SecTab.Div_Id = DivTab.Div_Id)"
      joba = "FieldEntry.JOB_ID = 1"
      cur.execute(f'''select {vala} from {taba} where {joia} AND {joba} and Date = {d1} GROUP BY SecTab.Div_Id''')
      rva = cur.fetchall()

      # GL TODAY
      vala1 = "SUM(FieldEntry.GL_Val)"
      taba1 = "DivTab, SecTab, FieldEntry"
      joia1 = "(FieldEntry.Sec_ID=SecTab.Sec_ID) AND (SecTab.Div_Id = DivTab.Div_Id)"
      joba1 = "FieldEntry.JOB_ID = 1"
      cur.execute(f'''select {vala1} from {taba1} where {joia1} AND {joba1} and Date = {d1} GROUP BY SecTab.Div_Id''')
      rva1 = cur.fetchall()

      #GL TODAY LAST YEA1R
      vala2 = "SUM(FieldEntry.GL_Val)"
      taba2 = "FieldEntry, DivTab, SecTab"
      joia2 = "(FieldEntry.Sec_ID=SecTab.Sec_ID) AND (SecTab.Div_Id = DivTab.Div_Id)"
      joba2 = "FieldEntry.JOB_ID = 1"
      cur.execute(f'''select {vala2} from {taba2} where {joia2} AND {joba2} and Date = {d11} GROUP BY SecTab.Div_Id''')
      rva2 = cur.fetchall()

      #FINE LEAF% TODAYS GL
      vala3 = "sum(FL_PER)"
      taba3 = "FLEntry, DivTab"
      joia3 = "(FLEntry.Div_Id = DivTab.Div_Id)"
      cur.execute(f'''select {vala3} from {taba3} where {joia3} and Date = {d1} GROUP BY DivTab.Div_Id''')
      rva3 = cur.fetchall()

      w = [i[0] for i in rva]
      x = [i1[0] for i1 in rva1]
      y = [i2[0] for i2 in rva2]
      z = [i3[0] for i3 in rva3]
      
      q = zip(w,x,y,z)
      json_data1 = []
      column_headers = ['Division','GLToday','GLTodayLY','FineLeaf']

      for row in q:
            json_data1.append(dict(zip(column_headers, row)))
      


#10## GRADE PER FACTORY

      cur = mysql.connection.cursor()

      #SUM-ALLGRADES-DATERANGE
      cur.execute(f"SELECT SUM(SortEntry.Sort_Kg) FROM SortEntry WHERE date ={d1} ")
      rv = cur.fetchall()

            #SUM-ALLGRADES-DATE
      cur.execute(f"SELECT SUM(SortEntry.Sort_Kg) FROM SortEntry WHERE date ={d1} ")
      rv3 = cur.fetchall()

            #SUM-PERGRADE-DATERANGE
      cur.execute(f"SELECT SUM(SortEntry.Sort_Kg) FROM SortEntry, TeaGradeTab WHERE SortEntry.TeaGrade_ID = TeaGradeTab.TeaGrade_ID and date ={d1} group by TeaGradeTab.TeaGrade_ID")
      rv1 = cur.fetchall()

            #PERGRADE-DATE
      cur.execute(f"SELECT SUM(SortEntry.Sort_Kg) FROM SortEntry, TeaGradeTab WHERE SortEntry.TeaGrade_ID = TeaGradeTab.TeaGrade_ID and date ={d1} group by TeaGradeTab.TeaGrade_ID ")
      rv4 = cur.fetchall()      

            #GRADE-NAME
      cur.execute(f"SELECT TeaGradeTab.TeaGrade_Name FROM SortEntry, TeaGradeTab WHERE SortEntry.TeaGrade_ID = TeaGradeTab.TeaGrade_ID and date ={d1}")
      rv2 = cur.fetchall()

      x = [s[0] for s in rv]
      xx = [s[0] for s in rv3]
      y = [i[0] for i in rv1]
      yy = [h[0] for h in rv4]
      w = [str(u[0]) for u in rv2]

      z = []
      for number in y:
            z.append((round((number / x[0]),2)*100))

      zz = []
      for number in yy:
            zz.append((round((number / xx[0]),2)*100))

      zzz = zip(w,zz,z)

      json_data5 = []    
      column_headers = ['Grade','PercentToday','PercentTodate']

      for row in zzz:
            json_data5.append(dict(zip(column_headers,row)))
      

      json_comp = {} 
      json_comp['TeaMade'] = json_data
      json_comp['Greenleaf'] = json_data1
      json_comp['GradePer'] =json_data5
      return json.dumps(json_comp)